

```python
%matplotlib inline
```


```python
import numpy as np
import pandas as pd
import seaborn
from pandas import Series, DataFrame
import matplotlib.pyplot as plt
```


```python
data = np.arange(10)
data
```




    array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])




```python
plt.plot(data)
```




    [<matplotlib.lines.Line2D at 0x2aa7b563e10>]




![png](output_3_1.png)



```python
plt.scatter(np.arange(30),np.arange(30)+3*np.random.randn(30))
```




    <matplotlib.collections.PathCollection at 0x2aa7c5c0a90>




![png](output_4_1.png)



```python
plt.hist(np.random.randn(30), bins=10, color='k', alpha=0.3)
```




    (array([4., 1., 6., 4., 3., 5., 2., 2., 1., 2.]),
     array([-2.18455151, -1.72544665, -1.26634179, -0.80723694, -0.34813208,
             0.11097278,  0.57007764,  1.02918249,  1.48828735,  1.94739221,
             2.40649707]),
     <a list of 10 Patch objects>)




![png](output_5_1.png)



```python
avocats = pd.read_csv("avocado.csv",sep=",")
```


```python
avocats
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Date</th>
      <th>AveragePrice</th>
      <th>Total_Volume</th>
      <th>4046</th>
      <th>4225</th>
      <th>4770</th>
      <th>Total_Bags</th>
      <th>Small_Bags</th>
      <th>Large_Bags</th>
      <th>Xlarge_Bags</th>
      <th>type</th>
      <th>year</th>
      <th>region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2015-12-27</td>
      <td>1.33</td>
      <td>64236.62</td>
      <td>1036.74</td>
      <td>54454.85</td>
      <td>48.16</td>
      <td>8696.87</td>
      <td>8603.62</td>
      <td>93.25</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2015-12-20</td>
      <td>1.35</td>
      <td>54876.98</td>
      <td>674.28</td>
      <td>44638.81</td>
      <td>58.33</td>
      <td>9505.56</td>
      <td>9408.07</td>
      <td>97.49</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2015-12-13</td>
      <td>0.93</td>
      <td>118220.22</td>
      <td>794.70</td>
      <td>109149.67</td>
      <td>130.50</td>
      <td>8145.35</td>
      <td>8042.21</td>
      <td>103.14</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2015-12-06</td>
      <td>1.08</td>
      <td>78992.15</td>
      <td>1132.00</td>
      <td>71976.41</td>
      <td>72.58</td>
      <td>5811.16</td>
      <td>5677.40</td>
      <td>133.76</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2015-11-29</td>
      <td>1.28</td>
      <td>51039.60</td>
      <td>941.48</td>
      <td>43838.39</td>
      <td>75.78</td>
      <td>6183.95</td>
      <td>5986.26</td>
      <td>197.69</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>2015-11-22</td>
      <td>1.26</td>
      <td>55979.78</td>
      <td>1184.27</td>
      <td>48067.99</td>
      <td>43.61</td>
      <td>6683.91</td>
      <td>6556.47</td>
      <td>127.44</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>2015-11-15</td>
      <td>0.99</td>
      <td>83453.76</td>
      <td>1368.92</td>
      <td>73672.72</td>
      <td>93.26</td>
      <td>8318.86</td>
      <td>8196.81</td>
      <td>122.05</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>2015-11-08</td>
      <td>0.98</td>
      <td>109428.33</td>
      <td>703.75</td>
      <td>101815.36</td>
      <td>80.00</td>
      <td>6829.22</td>
      <td>6266.85</td>
      <td>562.37</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>2015-11-01</td>
      <td>1.02</td>
      <td>99811.42</td>
      <td>1022.15</td>
      <td>87315.57</td>
      <td>85.34</td>
      <td>11388.36</td>
      <td>11104.53</td>
      <td>283.83</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>2015-10-25</td>
      <td>1.07</td>
      <td>74338.76</td>
      <td>842.40</td>
      <td>64757.44</td>
      <td>113.00</td>
      <td>8625.92</td>
      <td>8061.47</td>
      <td>564.45</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>10</th>
      <td>10</td>
      <td>2015-10-18</td>
      <td>1.12</td>
      <td>84843.44</td>
      <td>924.86</td>
      <td>75595.85</td>
      <td>117.07</td>
      <td>8205.66</td>
      <td>7877.86</td>
      <td>327.80</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>11</th>
      <td>11</td>
      <td>2015-10-11</td>
      <td>1.28</td>
      <td>64489.17</td>
      <td>1582.03</td>
      <td>52677.92</td>
      <td>105.32</td>
      <td>10123.90</td>
      <td>9866.27</td>
      <td>257.63</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>12</th>
      <td>12</td>
      <td>2015-10-04</td>
      <td>1.31</td>
      <td>61007.10</td>
      <td>2268.32</td>
      <td>49880.67</td>
      <td>101.36</td>
      <td>8756.75</td>
      <td>8379.98</td>
      <td>376.77</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>13</th>
      <td>13</td>
      <td>2015-09-27</td>
      <td>0.99</td>
      <td>106803.39</td>
      <td>1204.88</td>
      <td>99409.21</td>
      <td>154.84</td>
      <td>6034.46</td>
      <td>5888.87</td>
      <td>145.59</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>14</th>
      <td>14</td>
      <td>2015-09-20</td>
      <td>1.33</td>
      <td>69759.01</td>
      <td>1028.03</td>
      <td>59313.12</td>
      <td>150.50</td>
      <td>9267.36</td>
      <td>8489.10</td>
      <td>778.26</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>15</th>
      <td>15</td>
      <td>2015-09-13</td>
      <td>1.28</td>
      <td>76111.27</td>
      <td>985.73</td>
      <td>65696.86</td>
      <td>142.00</td>
      <td>9286.68</td>
      <td>8665.19</td>
      <td>621.49</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>16</th>
      <td>16</td>
      <td>2015-09-06</td>
      <td>1.11</td>
      <td>99172.96</td>
      <td>879.45</td>
      <td>90062.62</td>
      <td>240.79</td>
      <td>7990.10</td>
      <td>7762.87</td>
      <td>227.23</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>17</th>
      <td>17</td>
      <td>2015-08-30</td>
      <td>1.07</td>
      <td>105693.84</td>
      <td>689.01</td>
      <td>94362.67</td>
      <td>335.43</td>
      <td>10306.73</td>
      <td>10218.93</td>
      <td>87.80</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>18</th>
      <td>18</td>
      <td>2015-08-23</td>
      <td>1.34</td>
      <td>79992.09</td>
      <td>733.16</td>
      <td>67933.79</td>
      <td>444.78</td>
      <td>10880.36</td>
      <td>10745.79</td>
      <td>134.57</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>19</th>
      <td>19</td>
      <td>2015-08-16</td>
      <td>1.33</td>
      <td>80043.78</td>
      <td>539.65</td>
      <td>68666.01</td>
      <td>394.90</td>
      <td>10443.22</td>
      <td>10297.68</td>
      <td>145.54</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>20</th>
      <td>20</td>
      <td>2015-08-09</td>
      <td>1.12</td>
      <td>111140.93</td>
      <td>584.63</td>
      <td>100961.46</td>
      <td>368.95</td>
      <td>9225.89</td>
      <td>9116.34</td>
      <td>109.55</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>21</th>
      <td>21</td>
      <td>2015-08-02</td>
      <td>1.45</td>
      <td>75133.10</td>
      <td>509.94</td>
      <td>62035.06</td>
      <td>741.08</td>
      <td>11847.02</td>
      <td>11768.52</td>
      <td>78.50</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>22</th>
      <td>22</td>
      <td>2015-07-26</td>
      <td>1.11</td>
      <td>106757.10</td>
      <td>648.75</td>
      <td>91949.05</td>
      <td>966.61</td>
      <td>13192.69</td>
      <td>13061.53</td>
      <td>131.16</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>23</th>
      <td>23</td>
      <td>2015-07-19</td>
      <td>1.26</td>
      <td>96617.00</td>
      <td>1042.10</td>
      <td>82049.40</td>
      <td>2238.02</td>
      <td>11287.48</td>
      <td>11103.49</td>
      <td>183.99</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>24</th>
      <td>24</td>
      <td>2015-07-12</td>
      <td>1.05</td>
      <td>124055.31</td>
      <td>672.25</td>
      <td>94693.52</td>
      <td>4257.64</td>
      <td>24431.90</td>
      <td>24290.08</td>
      <td>108.49</td>
      <td>33.33</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>25</th>
      <td>25</td>
      <td>2015-07-05</td>
      <td>1.35</td>
      <td>109252.12</td>
      <td>869.45</td>
      <td>72600.55</td>
      <td>5883.16</td>
      <td>29898.96</td>
      <td>29663.19</td>
      <td>235.77</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>26</th>
      <td>26</td>
      <td>2015-06-28</td>
      <td>1.37</td>
      <td>89534.81</td>
      <td>664.23</td>
      <td>57545.79</td>
      <td>4662.71</td>
      <td>26662.08</td>
      <td>26311.76</td>
      <td>350.32</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>27</th>
      <td>27</td>
      <td>2015-06-21</td>
      <td>1.27</td>
      <td>104849.39</td>
      <td>804.01</td>
      <td>76688.55</td>
      <td>5481.18</td>
      <td>21875.65</td>
      <td>21662.00</td>
      <td>213.65</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>28</th>
      <td>28</td>
      <td>2015-06-14</td>
      <td>1.32</td>
      <td>89631.30</td>
      <td>850.58</td>
      <td>55400.94</td>
      <td>4377.19</td>
      <td>29002.59</td>
      <td>28343.14</td>
      <td>659.45</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>29</th>
      <td>29</td>
      <td>2015-06-07</td>
      <td>1.07</td>
      <td>122743.06</td>
      <td>656.71</td>
      <td>99220.82</td>
      <td>90.32</td>
      <td>22775.21</td>
      <td>22314.99</td>
      <td>460.22</td>
      <td>0.00</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18219</th>
      <td>6</td>
      <td>2018-02-11</td>
      <td>1.56</td>
      <td>1317000.47</td>
      <td>98465.26</td>
      <td>270798.27</td>
      <td>1839.80</td>
      <td>945638.02</td>
      <td>768242.42</td>
      <td>177144.00</td>
      <td>251.60</td>
      <td>organic</td>
      <td>2018</td>
      <td>TotalUS</td>
    </tr>
    <tr>
      <th>18220</th>
      <td>7</td>
      <td>2018-02-04</td>
      <td>1.53</td>
      <td>1384683.41</td>
      <td>117922.52</td>
      <td>287724.61</td>
      <td>1703.52</td>
      <td>977084.84</td>
      <td>774695.74</td>
      <td>201878.69</td>
      <td>510.41</td>
      <td>organic</td>
      <td>2018</td>
      <td>TotalUS</td>
    </tr>
    <tr>
      <th>18221</th>
      <td>8</td>
      <td>2018-01-28</td>
      <td>1.61</td>
      <td>1336979.09</td>
      <td>118616.17</td>
      <td>280080.34</td>
      <td>1270.61</td>
      <td>936859.49</td>
      <td>796104.27</td>
      <td>140652.84</td>
      <td>102.38</td>
      <td>organic</td>
      <td>2018</td>
      <td>TotalUS</td>
    </tr>
    <tr>
      <th>18222</th>
      <td>9</td>
      <td>2018-01-21</td>
      <td>1.63</td>
      <td>1283987.65</td>
      <td>108705.28</td>
      <td>259172.13</td>
      <td>1490.02</td>
      <td>914409.26</td>
      <td>710654.40</td>
      <td>203526.59</td>
      <td>228.27</td>
      <td>organic</td>
      <td>2018</td>
      <td>TotalUS</td>
    </tr>
    <tr>
      <th>18223</th>
      <td>10</td>
      <td>2018-01-14</td>
      <td>1.59</td>
      <td>1476651.08</td>
      <td>145680.62</td>
      <td>323669.83</td>
      <td>1580.01</td>
      <td>1005593.78</td>
      <td>858772.69</td>
      <td>146808.97</td>
      <td>12.12</td>
      <td>organic</td>
      <td>2018</td>
      <td>TotalUS</td>
    </tr>
    <tr>
      <th>18224</th>
      <td>11</td>
      <td>2018-01-07</td>
      <td>1.51</td>
      <td>1517332.70</td>
      <td>129541.43</td>
      <td>296490.29</td>
      <td>1289.07</td>
      <td>1089861.24</td>
      <td>915452.78</td>
      <td>174381.57</td>
      <td>26.89</td>
      <td>organic</td>
      <td>2018</td>
      <td>TotalUS</td>
    </tr>
    <tr>
      <th>18225</th>
      <td>0</td>
      <td>2018-03-25</td>
      <td>1.60</td>
      <td>271723.08</td>
      <td>26996.28</td>
      <td>77861.39</td>
      <td>117.56</td>
      <td>166747.85</td>
      <td>87108.00</td>
      <td>79495.39</td>
      <td>144.46</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18226</th>
      <td>1</td>
      <td>2018-03-18</td>
      <td>1.73</td>
      <td>210067.47</td>
      <td>33437.98</td>
      <td>47165.54</td>
      <td>110.40</td>
      <td>129353.55</td>
      <td>73163.12</td>
      <td>56020.24</td>
      <td>170.19</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18227</th>
      <td>2</td>
      <td>2018-03-11</td>
      <td>1.63</td>
      <td>264691.87</td>
      <td>27566.25</td>
      <td>60383.57</td>
      <td>276.42</td>
      <td>176465.63</td>
      <td>107174.93</td>
      <td>69290.70</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18228</th>
      <td>3</td>
      <td>2018-03-04</td>
      <td>1.46</td>
      <td>347373.17</td>
      <td>25990.60</td>
      <td>71213.19</td>
      <td>79.01</td>
      <td>250090.37</td>
      <td>85835.17</td>
      <td>164087.33</td>
      <td>167.87</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18229</th>
      <td>4</td>
      <td>2018-02-25</td>
      <td>1.49</td>
      <td>301985.61</td>
      <td>34200.18</td>
      <td>49139.34</td>
      <td>85.58</td>
      <td>218560.51</td>
      <td>99989.62</td>
      <td>118314.77</td>
      <td>256.12</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18230</th>
      <td>5</td>
      <td>2018-02-18</td>
      <td>1.64</td>
      <td>224798.60</td>
      <td>30149.00</td>
      <td>38800.64</td>
      <td>123.13</td>
      <td>155725.83</td>
      <td>120428.13</td>
      <td>35257.73</td>
      <td>39.97</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18231</th>
      <td>6</td>
      <td>2018-02-11</td>
      <td>1.47</td>
      <td>275248.53</td>
      <td>24732.55</td>
      <td>61713.53</td>
      <td>243.00</td>
      <td>188559.45</td>
      <td>88497.05</td>
      <td>99810.80</td>
      <td>251.60</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18232</th>
      <td>7</td>
      <td>2018-02-04</td>
      <td>1.41</td>
      <td>283378.47</td>
      <td>22474.66</td>
      <td>55360.49</td>
      <td>133.41</td>
      <td>205409.91</td>
      <td>70232.59</td>
      <td>134666.91</td>
      <td>510.41</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18233</th>
      <td>8</td>
      <td>2018-01-28</td>
      <td>1.80</td>
      <td>185974.53</td>
      <td>22918.40</td>
      <td>33051.14</td>
      <td>93.52</td>
      <td>129911.47</td>
      <td>77822.23</td>
      <td>51986.86</td>
      <td>102.38</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18234</th>
      <td>9</td>
      <td>2018-01-21</td>
      <td>1.83</td>
      <td>189317.99</td>
      <td>27049.44</td>
      <td>33561.32</td>
      <td>439.47</td>
      <td>128267.76</td>
      <td>76091.99</td>
      <td>51947.50</td>
      <td>228.27</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18235</th>
      <td>10</td>
      <td>2018-01-14</td>
      <td>1.82</td>
      <td>207999.67</td>
      <td>33869.12</td>
      <td>47435.14</td>
      <td>433.52</td>
      <td>126261.89</td>
      <td>89115.78</td>
      <td>37133.99</td>
      <td>12.12</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18236</th>
      <td>11</td>
      <td>2018-01-07</td>
      <td>1.48</td>
      <td>297190.60</td>
      <td>34734.97</td>
      <td>62967.74</td>
      <td>157.77</td>
      <td>199330.12</td>
      <td>103761.55</td>
      <td>95544.39</td>
      <td>24.18</td>
      <td>organic</td>
      <td>2018</td>
      <td>West</td>
    </tr>
    <tr>
      <th>18237</th>
      <td>0</td>
      <td>2018-03-25</td>
      <td>1.62</td>
      <td>15303.40</td>
      <td>2325.30</td>
      <td>2171.66</td>
      <td>0.00</td>
      <td>10806.44</td>
      <td>10569.80</td>
      <td>236.64</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18238</th>
      <td>1</td>
      <td>2018-03-18</td>
      <td>1.56</td>
      <td>15896.38</td>
      <td>2055.35</td>
      <td>1499.55</td>
      <td>0.00</td>
      <td>12341.48</td>
      <td>12114.81</td>
      <td>226.67</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18239</th>
      <td>2</td>
      <td>2018-03-11</td>
      <td>1.56</td>
      <td>22128.42</td>
      <td>2162.67</td>
      <td>3194.25</td>
      <td>8.93</td>
      <td>16762.57</td>
      <td>16510.32</td>
      <td>252.25</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18240</th>
      <td>3</td>
      <td>2018-03-04</td>
      <td>1.54</td>
      <td>17393.30</td>
      <td>1832.24</td>
      <td>1905.57</td>
      <td>0.00</td>
      <td>13655.49</td>
      <td>13401.93</td>
      <td>253.56</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18241</th>
      <td>4</td>
      <td>2018-02-25</td>
      <td>1.57</td>
      <td>18421.24</td>
      <td>1974.26</td>
      <td>2482.65</td>
      <td>0.00</td>
      <td>13964.33</td>
      <td>13698.27</td>
      <td>266.06</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18242</th>
      <td>5</td>
      <td>2018-02-18</td>
      <td>1.56</td>
      <td>17597.12</td>
      <td>1892.05</td>
      <td>1928.36</td>
      <td>0.00</td>
      <td>13776.71</td>
      <td>13553.53</td>
      <td>223.18</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18243</th>
      <td>6</td>
      <td>2018-02-11</td>
      <td>1.57</td>
      <td>15986.17</td>
      <td>1924.28</td>
      <td>1368.32</td>
      <td>0.00</td>
      <td>12693.57</td>
      <td>12437.35</td>
      <td>256.22</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18244</th>
      <td>7</td>
      <td>2018-02-04</td>
      <td>1.63</td>
      <td>17074.83</td>
      <td>2046.96</td>
      <td>1529.20</td>
      <td>0.00</td>
      <td>13498.67</td>
      <td>13066.82</td>
      <td>431.85</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18245</th>
      <td>8</td>
      <td>2018-01-28</td>
      <td>1.71</td>
      <td>13888.04</td>
      <td>1191.70</td>
      <td>3431.50</td>
      <td>0.00</td>
      <td>9264.84</td>
      <td>8940.04</td>
      <td>324.80</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18246</th>
      <td>9</td>
      <td>2018-01-21</td>
      <td>1.87</td>
      <td>13766.76</td>
      <td>1191.92</td>
      <td>2452.79</td>
      <td>727.94</td>
      <td>9394.11</td>
      <td>9351.80</td>
      <td>42.31</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18247</th>
      <td>10</td>
      <td>2018-01-14</td>
      <td>1.93</td>
      <td>16205.22</td>
      <td>1527.63</td>
      <td>2981.04</td>
      <td>727.01</td>
      <td>10969.54</td>
      <td>10919.54</td>
      <td>50.00</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>18248</th>
      <td>11</td>
      <td>2018-01-07</td>
      <td>1.62</td>
      <td>17489.58</td>
      <td>2894.77</td>
      <td>2356.13</td>
      <td>224.53</td>
      <td>12014.15</td>
      <td>11988.14</td>
      <td>26.01</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2018</td>
      <td>WestTexNewMexico</td>
    </tr>
  </tbody>
</table>
<p>18249 rows × 14 columns</p>
</div>




```python
avocats.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Date</th>
      <th>AveragePrice</th>
      <th>Total_Volume</th>
      <th>4046</th>
      <th>4225</th>
      <th>4770</th>
      <th>Total_Bags</th>
      <th>Small_Bags</th>
      <th>Large_Bags</th>
      <th>Xlarge_Bags</th>
      <th>type</th>
      <th>year</th>
      <th>region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>2015-12-27</td>
      <td>1.33</td>
      <td>64236.62</td>
      <td>1036.74</td>
      <td>54454.85</td>
      <td>48.16</td>
      <td>8696.87</td>
      <td>8603.62</td>
      <td>93.25</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2015-12-20</td>
      <td>1.35</td>
      <td>54876.98</td>
      <td>674.28</td>
      <td>44638.81</td>
      <td>58.33</td>
      <td>9505.56</td>
      <td>9408.07</td>
      <td>97.49</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2015-12-13</td>
      <td>0.93</td>
      <td>118220.22</td>
      <td>794.70</td>
      <td>109149.67</td>
      <td>130.50</td>
      <td>8145.35</td>
      <td>8042.21</td>
      <td>103.14</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>2015-12-06</td>
      <td>1.08</td>
      <td>78992.15</td>
      <td>1132.00</td>
      <td>71976.41</td>
      <td>72.58</td>
      <td>5811.16</td>
      <td>5677.40</td>
      <td>133.76</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>2015-11-29</td>
      <td>1.28</td>
      <td>51039.60</td>
      <td>941.48</td>
      <td>43838.39</td>
      <td>75.78</td>
      <td>6183.95</td>
      <td>5986.26</td>
      <td>197.69</td>
      <td>0.0</td>
      <td>conventional</td>
      <td>2015</td>
      <td>Albany</td>
    </tr>
  </tbody>
</table>
</div>




```python
nb_lignes, nb_col = avocats.shape
print(f"nb lignes : {nb_lignes}\nnb col : {nb_col}")
```

    nb lignes : 18249
    nb col : 14
    


```python
avocats.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>AveragePrice</th>
      <th>Total_Volume</th>
      <th>4046</th>
      <th>4225</th>
      <th>4770</th>
      <th>Total_Bags</th>
      <th>Small_Bags</th>
      <th>Large_Bags</th>
      <th>Xlarge_Bags</th>
      <th>year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>18249.000000</td>
      <td>18249.000000</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>1.824900e+04</td>
      <td>18249.000000</td>
      <td>18249.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>24.232232</td>
      <td>1.405978</td>
      <td>8.506440e+05</td>
      <td>2.930084e+05</td>
      <td>2.951546e+05</td>
      <td>2.283974e+04</td>
      <td>2.396392e+05</td>
      <td>1.821947e+05</td>
      <td>5.433809e+04</td>
      <td>3106.426507</td>
      <td>2016.147899</td>
    </tr>
    <tr>
      <th>std</th>
      <td>15.481045</td>
      <td>0.402677</td>
      <td>3.453545e+06</td>
      <td>1.264989e+06</td>
      <td>1.204120e+06</td>
      <td>1.074641e+05</td>
      <td>9.862424e+05</td>
      <td>7.461785e+05</td>
      <td>2.439660e+05</td>
      <td>17692.894652</td>
      <td>0.939938</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.440000</td>
      <td>8.456000e+01</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>2015.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>10.000000</td>
      <td>1.100000</td>
      <td>1.083858e+04</td>
      <td>8.540700e+02</td>
      <td>3.008780e+03</td>
      <td>0.000000e+00</td>
      <td>5.088640e+03</td>
      <td>2.849420e+03</td>
      <td>1.274700e+02</td>
      <td>0.000000</td>
      <td>2015.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>24.000000</td>
      <td>1.370000</td>
      <td>1.073768e+05</td>
      <td>8.645300e+03</td>
      <td>2.906102e+04</td>
      <td>1.849900e+02</td>
      <td>3.974383e+04</td>
      <td>2.636282e+04</td>
      <td>2.647710e+03</td>
      <td>0.000000</td>
      <td>2016.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>38.000000</td>
      <td>1.660000</td>
      <td>4.329623e+05</td>
      <td>1.110202e+05</td>
      <td>1.502069e+05</td>
      <td>6.243420e+03</td>
      <td>1.107834e+05</td>
      <td>8.333767e+04</td>
      <td>2.202925e+04</td>
      <td>132.500000</td>
      <td>2017.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>52.000000</td>
      <td>3.250000</td>
      <td>6.250565e+07</td>
      <td>2.274362e+07</td>
      <td>2.047057e+07</td>
      <td>2.546439e+06</td>
      <td>1.937313e+07</td>
      <td>1.338459e+07</td>
      <td>5.719097e+06</td>
      <td>551693.650000</td>
      <td>2018.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
avocats["AveragePrice"]
```




    0        1.33
    1        1.35
    2        0.93
    3        1.08
    4        1.28
    5        1.26
    6        0.99
    7        0.98
    8        1.02
    9        1.07
    10       1.12
    11       1.28
    12       1.31
    13       0.99
    14       1.33
    15       1.28
    16       1.11
    17       1.07
    18       1.34
    19       1.33
    20       1.12
    21       1.45
    22       1.11
    23       1.26
    24       1.05
    25       1.35
    26       1.37
    27       1.27
    28       1.32
    29       1.07
             ... 
    18219    1.56
    18220    1.53
    18221    1.61
    18222    1.63
    18223    1.59
    18224    1.51
    18225    1.60
    18226    1.73
    18227    1.63
    18228    1.46
    18229    1.49
    18230    1.64
    18231    1.47
    18232    1.41
    18233    1.80
    18234    1.83
    18235    1.82
    18236    1.48
    18237    1.62
    18238    1.56
    18239    1.56
    18240    1.54
    18241    1.57
    18242    1.56
    18243    1.57
    18244    1.63
    18245    1.71
    18246    1.87
    18247    1.93
    18248    1.62
    Name: AveragePrice, Length: 18249, dtype: float64




```python
avocats.dtypes
```




    Unnamed: 0        int64
    Date             object
    AveragePrice    float64
    Total_Volume    float64
    4046            float64
    4225            float64
    4770            float64
    Total_Bags      float64
    Small_Bags      float64
    Large_Bags      float64
    Xlarge_Bags     float64
    type             object
    year              int64
    region           object
    dtype: object




```python
avocats.columns
```




    Index(['Unnamed: 0', 'Date', 'AveragePrice', 'Total_Volume', '4046', '4225',
           '4770', 'Total_Bags', 'Small_Bags', 'Large_Bags', 'Xlarge_Bags', 'type',
           'year', 'region'],
          dtype='object')




```python
#GROUP BY
avocats.groupby("AveragePrice").Date.sum()
```




    AveragePrice
    0.44                                           2017-03-05
    0.46                                           2017-02-05
    0.48                                           2017-03-05
    0.49                                 2015-12-272017-02-26
    0.51    2015-04-192016-03-062017-01-012017-02-192017-0...
    0.52                       2015-06-072017-02-052017-03-05
    0.53    2015-12-202015-06-142015-04-262017-02-262017-0...
    0.54    2015-06-212016-02-072016-04-242016-03-272017-0...
    0.55                       2016-05-152016-02-072017-02-05
    0.56    2015-12-062015-07-052015-05-312015-02-012016-1...
    0.57    2015-04-052015-03-292016-05-082016-02-282017-0...
    0.58    2015-09-062015-05-242016-05-152016-02-072016-0...
    0.59    2016-02-072016-01-102018-03-252018-02-182018-0...
    0.60    2015-11-082015-05-032015-03-152015-02-152016-0...
    0.61    2015-01-252015-01-112016-05-082016-04-172016-0...
    0.62    2015-06-142015-11-152016-05-012016-06-192016-0...
    0.63    2015-02-222016-06-052016-05-292016-05-012016-0...
    0.64    2015-02-082016-05-082016-01-032016-12-252016-0...
    0.65    2015-06-142015-10-182015-01-042016-05-222016-0...
    0.66    2015-12-062015-12-132015-08-162015-04-122016-0...
    0.67    2015-03-222015-02-082015-05-172015-05-102015-0...
    0.68    2015-05-312015-02-012015-06-072016-05-152016-0...
    0.69    2015-06-142016-06-262016-12-182016-12-112016-1...
    0.70    2015-02-082015-07-122015-06-282015-03-012015-0...
    0.71    2015-12-062015-11-152015-01-042015-11-012015-0...
    0.72    2015-04-122015-03-152015-11-152015-06-072015-0...
    0.73    2015-06-072015-05-172015-12-132015-11-222015-0...
    0.74    2015-12-062015-01-042015-12-062015-06-282015-0...
    0.75    2015-06-212015-05-102015-03-082015-12-202015-1...
    0.76    2015-01-182015-01-112015-12-062015-05-102015-0...
                                  ...                        
    2.76    2015-08-022016-10-302017-04-302017-06-182017-0...
    2.77                       2015-08-302017-09-172017-06-11
    2.78                                           2017-10-08
    2.79             2015-10-182015-09-202016-10-022017-10-01
    2.80                                 2017-09-102017-10-08
    2.81                       2017-04-162017-09-242017-09-03
    2.82                       2016-11-062017-10-012017-09-03
    2.83    2016-09-252017-08-272017-04-162017-09-172017-0...
    2.84             2017-09-102017-09-032017-08-272017-08-27
    2.85             2016-10-162017-10-082017-08-272017-10-08
    2.86             2017-10-012017-10-012017-09-172017-09-10
    2.87                       2017-10-152017-09-102017-08-20
    2.88                       2016-11-272017-03-192017-10-01
    2.89                       2016-10-302017-09-102017-09-03
    2.90                                           2017-03-12
    2.91                                           2016-09-25
    2.92                                 2017-09-172017-03-05
    2.93             2016-10-232016-10-162017-08-202017-09-03
    2.94                                 2016-11-202017-09-17
    2.95                                           2017-09-24
    2.96                                           2017-08-27
    2.97                                           2017-09-03
    2.99                                 2016-11-132017-10-01
    3.00                                 2017-10-012017-08-27
    3.03                                           2016-10-02
    3.04                                           2017-08-27
    3.05                                           2017-03-12
    3.12                                           2016-11-06
    3.17                                           2017-04-16
    3.25                                           2016-10-30
    Name: Date, Length: 259, dtype: object




```python
#SORT
avocats.sort_values(by="AveragePrice")[-20:]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Date</th>
      <th>AveragePrice</th>
      <th>Total_Volume</th>
      <th>4046</th>
      <th>4225</th>
      <th>4770</th>
      <th>Total_Bags</th>
      <th>Small_Bags</th>
      <th>Large_Bags</th>
      <th>Xlarge_Bags</th>
      <th>type</th>
      <th>year</th>
      <th>region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>16717</th>
      <td>15</td>
      <td>2017-09-17</td>
      <td>2.92</td>
      <td>10297.07</td>
      <td>89.79</td>
      <td>4298.97</td>
      <td>161.11</td>
      <td>5747.20</td>
      <td>5319.20</td>
      <td>428.00</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>RaleighGreensboro</td>
    </tr>
    <tr>
      <th>16986</th>
      <td>19</td>
      <td>2017-08-20</td>
      <td>2.93</td>
      <td>21524.58</td>
      <td>9571.06</td>
      <td>7792.22</td>
      <td>0.00</td>
      <td>4161.30</td>
      <td>4161.30</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>SanFrancisco</td>
    </tr>
    <tr>
      <th>14699</th>
      <td>10</td>
      <td>2016-10-16</td>
      <td>2.93</td>
      <td>5373.88</td>
      <td>901.06</td>
      <td>3284.87</td>
      <td>8.55</td>
      <td>1179.40</td>
      <td>1146.07</td>
      <td>33.33</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2016</td>
      <td>WestTexNewMexico</td>
    </tr>
    <tr>
      <th>17249</th>
      <td>17</td>
      <td>2017-09-03</td>
      <td>2.93</td>
      <td>3047.66</td>
      <td>181.79</td>
      <td>1194.91</td>
      <td>0.00</td>
      <td>1670.96</td>
      <td>452.22</td>
      <td>1218.74</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>Spokane</td>
    </tr>
    <tr>
      <th>14126</th>
      <td>9</td>
      <td>2016-10-23</td>
      <td>2.93</td>
      <td>11252.48</td>
      <td>522.51</td>
      <td>7911.64</td>
      <td>0.00</td>
      <td>2818.33</td>
      <td>2818.33</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2016</td>
      <td>SanFrancisco</td>
    </tr>
    <tr>
      <th>14122</th>
      <td>5</td>
      <td>2016-11-20</td>
      <td>2.94</td>
      <td>17436.41</td>
      <td>5926.88</td>
      <td>7823.25</td>
      <td>0.00</td>
      <td>3686.28</td>
      <td>3620.25</td>
      <td>66.03</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2016</td>
      <td>SanFrancisco</td>
    </tr>
    <tr>
      <th>17247</th>
      <td>15</td>
      <td>2017-09-17</td>
      <td>2.94</td>
      <td>2375.19</td>
      <td>181.23</td>
      <td>861.34</td>
      <td>0.00</td>
      <td>1332.62</td>
      <td>312.22</td>
      <td>1020.40</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>Spokane</td>
    </tr>
    <tr>
      <th>17246</th>
      <td>14</td>
      <td>2017-09-24</td>
      <td>2.95</td>
      <td>2417.55</td>
      <td>168.12</td>
      <td>1025.14</td>
      <td>0.00</td>
      <td>1224.29</td>
      <td>370.00</td>
      <td>849.73</td>
      <td>4.56</td>
      <td>organic</td>
      <td>2017</td>
      <td>Spokane</td>
    </tr>
    <tr>
      <th>17038</th>
      <td>18</td>
      <td>2017-08-27</td>
      <td>2.96</td>
      <td>26845.68</td>
      <td>1134.59</td>
      <td>11055.60</td>
      <td>12.57</td>
      <td>14642.92</td>
      <td>1079.26</td>
      <td>13563.66</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>Seattle</td>
    </tr>
    <tr>
      <th>16719</th>
      <td>17</td>
      <td>2017-09-03</td>
      <td>2.97</td>
      <td>14052.55</td>
      <td>169.06</td>
      <td>4855.92</td>
      <td>148.96</td>
      <td>8878.61</td>
      <td>8315.09</td>
      <td>563.52</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>RaleighGreensboro</td>
    </tr>
    <tr>
      <th>14123</th>
      <td>6</td>
      <td>2016-11-13</td>
      <td>2.99</td>
      <td>18930.40</td>
      <td>6204.65</td>
      <td>9341.41</td>
      <td>0.00</td>
      <td>3384.34</td>
      <td>3337.67</td>
      <td>46.67</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2016</td>
      <td>SanFrancisco</td>
    </tr>
    <tr>
      <th>15814</th>
      <td>13</td>
      <td>2017-10-01</td>
      <td>2.99</td>
      <td>2819.87</td>
      <td>174.13</td>
      <td>703.73</td>
      <td>12.01</td>
      <td>1930.00</td>
      <td>1736.97</td>
      <td>193.03</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>Jacksonville</td>
    </tr>
    <tr>
      <th>16985</th>
      <td>18</td>
      <td>2017-08-27</td>
      <td>3.00</td>
      <td>19329.49</td>
      <td>10517.41</td>
      <td>7907.99</td>
      <td>0.00</td>
      <td>904.09</td>
      <td>900.76</td>
      <td>3.33</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>SanFrancisco</td>
    </tr>
    <tr>
      <th>16715</th>
      <td>13</td>
      <td>2017-10-01</td>
      <td>3.00</td>
      <td>10741.93</td>
      <td>140.46</td>
      <td>4331.20</td>
      <td>147.11</td>
      <td>6123.16</td>
      <td>5873.99</td>
      <td>249.17</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>RaleighGreensboro</td>
    </tr>
    <tr>
      <th>13037</th>
      <td>12</td>
      <td>2016-10-02</td>
      <td>3.03</td>
      <td>3714.71</td>
      <td>296.71</td>
      <td>2699.80</td>
      <td>0.00</td>
      <td>718.20</td>
      <td>718.20</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2016</td>
      <td>LasVegas</td>
    </tr>
    <tr>
      <th>16720</th>
      <td>18</td>
      <td>2017-08-27</td>
      <td>3.04</td>
      <td>12656.32</td>
      <td>419.06</td>
      <td>4851.90</td>
      <td>145.09</td>
      <td>7240.27</td>
      <td>6960.97</td>
      <td>279.30</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>RaleighGreensboro</td>
    </tr>
    <tr>
      <th>16055</th>
      <td>42</td>
      <td>2017-03-12</td>
      <td>3.05</td>
      <td>2068.26</td>
      <td>1043.83</td>
      <td>77.36</td>
      <td>0.00</td>
      <td>947.07</td>
      <td>926.67</td>
      <td>20.40</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>MiamiFtLauderdale</td>
    </tr>
    <tr>
      <th>14124</th>
      <td>7</td>
      <td>2016-11-06</td>
      <td>3.12</td>
      <td>19043.80</td>
      <td>5898.49</td>
      <td>10039.34</td>
      <td>0.00</td>
      <td>3105.97</td>
      <td>3079.30</td>
      <td>26.67</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2016</td>
      <td>SanFrancisco</td>
    </tr>
    <tr>
      <th>17428</th>
      <td>37</td>
      <td>2017-04-16</td>
      <td>3.17</td>
      <td>3018.56</td>
      <td>1255.55</td>
      <td>82.31</td>
      <td>0.00</td>
      <td>1680.70</td>
      <td>1542.22</td>
      <td>138.48</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2017</td>
      <td>Tampa</td>
    </tr>
    <tr>
      <th>14125</th>
      <td>8</td>
      <td>2016-10-30</td>
      <td>3.25</td>
      <td>16700.94</td>
      <td>2325.93</td>
      <td>11142.85</td>
      <td>0.00</td>
      <td>3232.16</td>
      <td>3232.16</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>organic</td>
      <td>2016</td>
      <td>SanFrancisco</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Top des volumes vendus par région
volRegion = avocats.groupby("region").Total_Volume.sum().sort_values()
volRegion
```




    region
    Syracuse               1.094267e+07
    Boise                  1.441319e+07
    Spokane                1.556528e+07
    Albany                 1.606780e+07
    Louisville             1.609700e+07
    Pittsburgh             1.880635e+07
    BuffaloRochester       2.296247e+07
    Roanoke                2.504201e+07
    Jacksonville           2.879000e+07
    Columbus               2.999336e+07
    GrandRapids            3.021174e+07
    Indianapolis           3.026339e+07
    StLouis                3.207283e+07
    Charlotte              3.555554e+07
    Nashville              3.561209e+07
    HarrisburgScranton     4.180886e+07
    RichmondNorfolk        4.223085e+07
    CincinnatiDayton       4.452201e+07
    NewOrleansMobile       4.569514e+07
    RaleighGreensboro      4.820273e+07
    HartfordSpringfield    5.067054e+07
    LasVegas               5.437691e+07
    Orlando                5.866070e+07
    SouthCarolina          6.075377e+07
    Detroit                6.342242e+07
    Tampa                  6.600454e+07
    NorthernNewEngland     7.153289e+07
    Philadelphia           7.183880e+07
    Sacramento             7.516375e+07
    Atlanta                8.860512e+07
    SanDiego               8.979192e+07
    Boston                 9.727398e+07
    MiamiFtLauderdale      9.767322e+07
    Seattle                1.092142e+08
    Portland               1.105522e+08
    Chicago                1.337023e+08
    BaltimoreWashington    1.347139e+08
    SanFrancisco           1.358302e+08
    Denver                 1.389025e+08
    WestTexNewMexico       1.445218e+08
    PhoenixTucson          1.956433e+08
    Houston                2.031679e+08
    DallasFtWorth          2.084193e+08
    NewYork                2.407341e+08
    Plains                 3.111885e+08
    LosAngeles             5.078965e+08
    Midsouth               5.083494e+08
    GreatLakes             5.896425e+08
    Southeast              6.152384e+08
    Northeast              7.132809e+08
    SouthCentral           1.011280e+09
    California             1.028982e+09
    West                   1.086779e+09
    TotalUS                5.864740e+09
    Name: Total_Volume, dtype: float64




```python
#Prix moyen des avocats par région
prixMoyRegion = avocats.groupby("region").AveragePrice.mean().sort_values()
prixMoyRegion
```




    region
    Houston                1.047929
    DallasFtWorth          1.085592
    SouthCentral           1.101243
    CincinnatiDayton       1.209201
    Nashville              1.212101
    LosAngeles             1.216006
    Denver                 1.218580
    PhoenixTucson          1.224438
    Roanoke                1.247929
    Columbus               1.252781
    WestTexNewMexico       1.261701
    West                   1.272219
    Detroit                1.276095
    Louisville             1.286686
    RichmondNorfolk        1.291331
    NewOrleansMobile       1.304793
    Indianapolis           1.313994
    Portland               1.317722
    TotalUS                1.319024
    Atlanta                1.337959
    GreatLakes             1.338550
    Boise                  1.348136
    Pittsburgh             1.364320
    LasVegas               1.380917
    California             1.395325
    Southeast              1.398018
    SanDiego               1.398166
    SouthCarolina          1.403284
    Midsouth               1.404763
    Tampa                  1.408846
    MiamiFtLauderdale      1.428491
    StLouis                1.430621
    Plains                 1.436509
    Seattle                1.442574
    Spokane                1.445592
    NorthernNewEngland     1.477396
    GrandRapids            1.505000
    Orlando                1.506213
    Jacksonville           1.510947
    HarrisburgScranton     1.513284
    BuffaloRochester       1.516834
    Syracuse               1.520325
    Boston                 1.530888
    BaltimoreWashington    1.534231
    RaleighGreensboro      1.555118
    Chicago                1.556775
    Albany                 1.561036
    Northeast              1.601923
    Charlotte              1.606036
    Sacramento             1.621568
    Philadelphia           1.632130
    NewYork                1.727574
    SanFrancisco           1.804201
    HartfordSpringfield    1.818639
    Name: AveragePrice, dtype: float64




```python
plt.rcParams['figure.figsize'] = [15, 6] # Taille du graphique en pouces
plt.rcParams['figure.dpi'] = 200 # résolution en points par pouce
avocats[(avocats.region=="Houston")].groupby("Date").AveragePrice.mean().plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2aa7d1ad668>




![png](output_18_1.png)



```python
plt.rcParams['figure.figsize'] = [15, 6] # Taille du graphique en pouces
plt.rcParams['figure.dpi'] = 200 # résolution en points par pouce
avocats[(avocats.region=="Houston")].groupby("Date").Total_Volume.mean().plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2aa7d236da0>




![png](output_19_1.png)



```python
plt.rcParams['figure.figsize'] = [15, 6] # Taille du graphique en pouces
plt.rcParams['figure.dpi'] = 200 # résolution en points par pouce
avocats[(avocats.region=="HartfordSpringfield")].groupby("Date").AveragePrice.mean().plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2aa7d21fcc0>




![png](output_20_1.png)



```python
plt.rcParams['figure.figsize'] = [15, 6] # Taille du graphique en pouces
plt.rcParams['figure.dpi'] = 200 # résolution en points par pouce
avocats[(avocats.region=="HartfordSpringfield")].groupby("Date").Total_Volume.mean().plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x2aa7d212208>




![png](output_21_1.png)


Chaque fois que le prix baisse, le volume vendu augmente, que ce soit à Houston, où les prix sont en moyenne les plus bas, ou à Hartford Springfield, où les prix sont en moyenne les plus élevés.


```python

```
